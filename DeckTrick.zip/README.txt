- First of all, unpack the file "DeckTric.zip" to any folder of your PC;
- Run the file "index.html" in your web browser, preferably Chrome;
- Enjoy it! We wish you love it!!!

By Alexandre Magno.