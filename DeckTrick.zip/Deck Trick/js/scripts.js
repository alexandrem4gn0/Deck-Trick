function isChecked() {
    var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "start.html"
	} else if (radio1) window.location.href = "secondround.html"
		if (radio2) window.location.href = "secondround2.html"
		if (radio3) window.location.href = "secondround3.html"
}

function isChecked2() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "secondround.html"
	} else if (radio1) window.location.href = "lastround.html"
		if (radio2) window.location.href = "lastround2.html"
		if (radio3) window.location.href = "lastround3.html"
}

function isChecked2_2() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "secondround2.html"
	} else if (radio1) window.location.href = "lastround4.html"
		if (radio2) window.location.href = "lastround5.html"
		if (radio3) window.location.href = "lastround6.html"
}

function isChecked2_3() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "secondround3.html"
	} else if (radio1) window.location.href = "lastround7.html"
		if (radio2) window.location.href = "lastround8.html"
		if (radio3) window.location.href = "lastround9.html"
}

function isChecked3() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround.html"
	} else if (radio1) window.location.href = "theend.html"
		if (radio2) window.location.href = "theend02.html"
		if (radio3) window.location.href = "theend03.html"
}

function isChecked3_2() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround2.html"
	} else if (radio1) window.location.href = "theend20.html"
		if (radio2) window.location.href = "theend21.html"
		if (radio3) window.location.href = "theend06.html"
}

function isChecked3_3() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround3.html"
	} else if (radio1) window.location.href = "theend07.html"
		if (radio2) window.location.href = "theend08.html"
		if (radio3) window.location.href = "theend09.html"
}

function isChecked3_4() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround4.html"
	} else if (radio1) window.location.href = "theend12.html"
		if (radio2) window.location.href = "theend13.html"
		if (radio3) window.location.href = "theend20.html"
}

function isChecked3_5() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround5.html"
	} else if (radio1) window.location.href = "theend10.html"
		if (radio2) window.location.href = "theend11.html"
		if (radio3) window.location.href = "theend07.html"
}

function isChecked3_6() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround6.html"
	} else if (radio1) window.location.href = "theend05.html"
		if (radio2) window.location.href = "theend14.html"
		if (radio3) window.location.href = "theend15.html"
}

function isChecked3_7() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround7.html"
	} else if (radio1) window.location.href = "theend16.html"
		if (radio2) window.location.href = "theend17.html"
		if (radio3) window.location.href = "theend20.html"
}

function isChecked3_8() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround8.html"
	} else if (radio1) window.location.href = "theend03.html"
		if (radio2) window.location.href = "theend04.html"
		if (radio3) window.location.href = "theend05.html"
}

function isChecked3_9() {
	var radio1 = document.getElementById("choice1").checked
	var radio2 = document.getElementById("choice2").checked
	var radio3 = document.getElementById("choice3").checked

    if (!radio1&&!radio2&&!radio3){
    	alert('Please choose one column!')
		window.location.href = "lastround9.html"
	} else if (radio1) window.location.href = "theend07.html"
		if (radio2) window.location.href = "theend18.html"
		if (radio3) window.location.href = "theend19.html"
}